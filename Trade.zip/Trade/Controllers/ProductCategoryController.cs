﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Trade.Model;

namespace Trade.Controllers
{
    public class ProductCategoryController
    {
        Core db = new Core();

        public List<ProductCategory> GetCategories()
        {
            return db.context.ProductCategory.ToList();
        }
    }
}
