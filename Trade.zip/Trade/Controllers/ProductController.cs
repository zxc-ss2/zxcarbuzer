﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Trade.Model;

namespace Trade.Controllers
{
    public class ProductController
    {
        Core db = new Core();
        public List<Product> GetProducts()
        {
            return db.context.Product.ToList();
        }
    }
}
