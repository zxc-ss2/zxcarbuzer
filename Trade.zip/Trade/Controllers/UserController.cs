﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Trade.Model;

namespace Trade.Controllers
{
    public class UserController
    {
        Core db = new Core();

        public int GetRoleForAuth()
        {
            string login = App.userLogin;
            string password = App.userPassword;

            var user = Auth(login, password);

            if(user != null)
            {
                return user.UserRole;
            }

            return 0;
        }

        public User Auth(string login, string password)
        {
            var user = db.context.User.Where(x => x.UserLogin == login && x.UserPassword == password).FirstOrDefault();
            return user;
        }
    }
}
