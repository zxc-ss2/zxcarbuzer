﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trade.Model
{
    public partial class Product
    {
        public byte[] CustomImage
        {
            get
            {
                string fullAppPath = Directory.GetCurrentDirectory();
                string localAppPath = fullAppPath.Replace(@"\bin\Debug", "");

                if (ProductPhotoPath != null && ProductPhoto == null)
                {
                    var newProductPhotoPath = ProductPhotoPath.Replace(System.Environment.NewLine, "");
                    if (new FileInfo(localAppPath + $@"\Assets\Images\Products\" + newProductPhotoPath).Exists)
                    {
                        return File.ReadAllBytes(localAppPath + @"\Assets\Images\Products\" + newProductPhotoPath);
                    }

                    else 
                    { 
                        return File.ReadAllBytes(localAppPath + @"\Assets\Images\picture.png");
                    }
                }

                else if(ProductPhotoPath == null && ProductPhoto == null)
                {
                    return File.ReadAllBytes(localAppPath + @"\Assets\Images\picture.png");
                }

                else
                {
                    return ProductPhoto;
                }

            }
        }

        public string Name
        {
            get
            {
                return ProductName;
            }
        }

        public string Description
        {
            get
            {
                return ProductDescription;
            }
        }

        public string Manufacturer
        {
            get
            {
                return ProductManufacturer;
            }
        }

    }
}
