﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Trade.Model;

namespace Trade.View.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEdditProductPage.xaml
    /// </summary>
    public partial class AddEdditProductPage : Page
    {
        Core db = new Core();
        public AddEdditProductPage(Product selectedProduct)
        {
            InitializeComponent();
        }

        public byte[] prostoPhoto = null;

        private void AddEdditImageBtn_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog imageSelected = new OpenFileDialog();

            if(imageSelected.ShowDialog() == true)
            {
                string selectedImageName = imageSelected.FileName;
                if (new FileInfo(selectedImageName).Exists)
                {
                    prostoPhoto = File.ReadAllBytes(selectedImageName);
                    PreviewImage.Source = (ImageSource)new ImageSourceConverter().ConvertFrom(prostoPhoto);

                    string fullAppPath = Directory.GetCurrentDirectory();
                    string localAppPath = fullAppPath.Replace(@"\bin\Debug", "");

                    string newImagePath = localAppPath + @"\Assets\Images\Products\" + System.IO.Path.GetFileName(selectedImageName);
                    File.Copy(selectedImageName, newImagePath, true);

                }
            }
        }

        private void SaveBtn_Click(object sender, RoutedEventArgs e)
        {
            db.context.Product.Add(new Product
            {
                ProductArticleNumber = "3dsfasdf",
                ProductPhoto = prostoPhoto,
                ProductPhotoPath = null
            });

            db.context.SaveChanges();
        }
    }
}
