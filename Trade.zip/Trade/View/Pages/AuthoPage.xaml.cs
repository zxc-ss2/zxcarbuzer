﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Trade.Controllers;

namespace Trade.View.Pages
{
    /// <summary>
    /// Логика взаимодействия для AuthoPage.xaml
    /// </summary>
    public partial class AuthoPage : Page
    {
        readonly UserController userController = new UserController();
        public AuthoPage()
        {
            InitializeComponent();
        }

        private void LoginBtn_Click(object sender, RoutedEventArgs e)
        {
            App.userLogin = UserLoginTextBox.Text;
            App.userPassword = UserPasswordTextBox.Text;

            switch (userController.GetRoleForAuth())
            {
                case 1:
                    App.adminCheck = true;
                    this.NavigationService.Navigate(new ProductPage());
                    break;
                case 2:
                    App.managerCheck = true;
                    this.NavigationService.Navigate(new ProductPage());
                    break;
                case 3:
                    App.clientCheck = true;
                    this.NavigationService.Navigate(new ProductPage());
                    break;
                default:
                    MessageBox.Show("Ошибка авторизации, неверный логин или пароль");
                    break;
            }
        }
    }
}
